import React, { createContext, useState, useContext, useEffect } from 'react';

const TradeContext = createContext();

export const TradeProvider = ({ children }) => {
  const [holdings, setHoldings] = useState(() => {
    const savedHoldings = localStorage.getItem('holdings');
    return savedHoldings ? JSON.parse(savedHoldings) : [];
  });

  const [transactions, setTransactions] = useState(() => {
    const savedTransactions = localStorage.getItem('transactions');
    return savedTransactions ? JSON.parse(savedTransactions) : [];
  });

  const handleTrade = (tradeDetails) => {
    try {
      // Add transaction to history
      const newTransaction = {
        ...tradeDetails,
        date: new Date().toISOString(),
      };
      const updatedTransactions = [newTransaction, ...transactions];
      setTransactions(updatedTransactions);
      localStorage.setItem('transactions', JSON.stringify(updatedTransactions));

      // Update holdings
      let updatedHoldings = [...holdings];
      const stockIndex = updatedHoldings.findIndex(h => h.symbol === tradeDetails.symbol);

      if (tradeDetails.type === 'BUY') {
        if (stockIndex === -1) {
          // New stock purchase
          const newHolding = {
            symbol: tradeDetails.symbol,
            shares: Number(tradeDetails.quantity),
            avgPrice: Number(tradeDetails.price),
            currentPrice: Number(tradeDetails.price),
            value: Number(tradeDetails.quantity) * Number(tradeDetails.price),
            gain: 0,
            gainPercent: 0
          };
          updatedHoldings = [...updatedHoldings, newHolding];
        } else {
          // Existing stock
          const stock = updatedHoldings[stockIndex];
          const newShares = Number(stock.shares) + Number(tradeDetails.quantity);
          const newTotalValue = (stock.shares * stock.avgPrice) + (Number(tradeDetails.quantity) * Number(tradeDetails.price));
          stock.shares = newShares;
          stock.avgPrice = newTotalValue / newShares;
          stock.currentPrice = Number(tradeDetails.price);
          stock.value = stock.shares * stock.currentPrice;
          stock.gain = stock.value - (stock.shares * stock.avgPrice);
          stock.gainPercent = (stock.gain / (stock.shares * stock.avgPrice)) * 100;
        }
      } else {
        // Sell
        const stock = updatedHoldings[stockIndex];
        stock.shares -= Number(tradeDetails.quantity);
        if (stock.shares === 0) {
          updatedHoldings = updatedHoldings.filter(h => h.symbol !== tradeDetails.symbol);
        } else {
          stock.currentPrice = Number(tradeDetails.price);
          stock.value = stock.shares * stock.currentPrice;
          stock.gain = stock.value - (stock.shares * stock.avgPrice);
          stock.gainPercent = (stock.gain / (stock.shares * stock.avgPrice)) * 100;
        }
      }

      // Update state
      setHoldings(updatedHoldings);
      localStorage.setItem('holdings', JSON.stringify(updatedHoldings));

    } catch (error) {
      console.error('Error processing trade:', error);
    }
  };

  return (
    <TradeContext.Provider value={{ holdings, transactions, handleTrade }}>
      {children}
    </TradeContext.Provider>
  );
};

export const useTrade = () => {
  const context = useContext(TradeContext);
  if (!context) {
    throw new Error('useTrade must be used within a TradeProvider');
  }
  return context;
}; 