import React, { useState, useEffect } from 'react';
import '../styles/TradeModal.css';

const TradeModal = ({ isOpen, onClose, stock, type, onTrade }) => {
  const [quantity, setQuantity] = useState(1);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState('');

  useEffect(() => {
    if (stock) {
      setTotal(quantity * stock.currentPrice);
    }
  }, [quantity, stock]);

  const handleQuantityChange = (e) => {
    const value = parseInt(e.target.value) || 0;
    setQuantity(value);
    setError('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (quantity <= 0) {
      setError('Quantity must be greater than 0');
      return;
    }

    onTrade({
      symbol: stock.symbol,
      quantity,
      price: stock.currentPrice,
      total: quantity * stock.currentPrice,
      type: type.toUpperCase()
    });

    onClose();
  };

  if (!isOpen || !stock) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="modal-close" onClick={onClose}>&times;</button>
        <h2>{type === 'buy' ? 'Buy' : 'Sell'} {stock.symbol}</h2>
        
        <div className="stock-info">
          <div className="info-row">
            <span>Current Price:</span>
            <span className="price">₹{stock.currentPrice.toFixed(2)}</span>
          </div>
          {type === 'sell' && stock.avgPrice && (
            <div className="info-row">
              <span>Average Buy Price:</span>
              <span>₹{stock.avgPrice.toFixed(2)}</span>
            </div>
          )}
          {type === 'sell' && stock.shares && (
            <div className="info-row">
              <span>Available Shares:</span>
              <span>{stock.shares}</span>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="quantity">Quantity</label>
            <input
              type="number"
              id="quantity"
              value={quantity}
              onChange={handleQuantityChange}
              min="1"
              max={type === 'sell' ? stock.shares : undefined}
            />
          </div>

          <div className="trade-summary">
            <div className="info-row">
              <span>Total Amount:</span>
              <span className="total">₹{total.toFixed(2)}</span>
            </div>
          </div>

          {error && <div className="error-message">{error}</div>}

          <button 
            type="submit" 
            className={`trade-button ${type}`}
            disabled={quantity <= 0 || (type === 'sell' && quantity > stock.shares)}
          >
            {type === 'buy' ? 'Buy' : 'Sell'} {stock.symbol}
          </button>
        </form>
      </div>
    </div>
  );
};

export default TradeModal; 