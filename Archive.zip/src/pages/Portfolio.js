import React, { useState, useEffect } from 'react';
import '../styles/Portfolio.css';
import Chart from 'react-apexcharts';
import TradeModal from '../components/TradeModal';
import { useTrade } from '../context/TradeContext';

const Portfolio = () => {
  const { holdings, transactions, handleTrade } = useTrade();
  
  // Portfolio data state
  const [portfolioData, setPortfolioData] = useState({
    totalValue: 0,
    todayChange: 0,
    todayChangePercent: 0,
    totalInvestment: 0,
    totalGain: 0,
    totalGainPercent: 0
  });

  // Calculate portfolio data whenever holdings change
  useEffect(() => {
    if (holdings.length > 0) {
      const totalValue = holdings.reduce((sum, stock) => sum + stock.value, 0);
      const totalInvestment = holdings.reduce((sum, stock) => sum + (stock.shares * stock.avgPrice), 0);
      const totalGain = totalValue - totalInvestment;
      const totalGainPercent = totalInvestment > 0 ? (totalGain / totalInvestment) * 100 : 0;
      
      setPortfolioData({
        totalValue,
        totalInvestment,
        totalGain,
        totalGainPercent,
        todayChange: totalGain,
        todayChangePercent: totalGainPercent
      });
    }
  }, [holdings]);

  const portfolioChartOptions = {
    chart: {
      type: 'area',
      height: 250,
      toolbar: {
        show: false
      },
      background: 'transparent'
    },
    colors: ['#00f962'],
    stroke: {
      curve: 'smooth',
      width: 2
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.3,
        opacityTo: 0.1,
        stops: [0, 90, 100]
      }
    },
    dataLabels: {
      enabled: false
    },
    xaxis: {
      type: 'datetime',
      labels: {
        style: {
          colors: '#888'
        }
      },
      axisBorder: {
        show: false
      },
      axisTicks: {
        show: false
      }
    },
    yaxis: {
      labels: {
        style: {
          colors: '#888'
        },
        formatter: (value) => `₹${value.toFixed(2)}`
      }
    },
    tooltip: {
      theme: 'dark',
      x: {
        format: 'dd MMM yyyy'
      }
    },
    grid: {
      borderColor: 'rgba(255, 255, 255, 0.1)',
      strokeDashArray: 4,
      xaxis: {
        lines: {
          show: true
        }
      },
      yaxis: {
        lines: {
          show: true
        }
      }
    }
  };

  // Sample portfolio value data
  const [portfolioChartData] = useState([
    {
      name: 'Portfolio Value',
      data: [
        [new Date('2024-02-15').getTime(), 145000],
        [new Date('2024-02-20').getTime(), 147500],
        [new Date('2024-02-25').getTime(), 146800],
        [new Date('2024-03-01').getTime(), 149200],
        [new Date('2024-03-05').getTime(), 151500],
        [new Date('2024-03-10').getTime(), 154000],
        [new Date('2024-03-15').getTime(), 156789.45],
      ]
    }
  ]);

  const [selectedStock, setSelectedStock] = useState(null);
  const [tradeType, setTradeType] = useState(null);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);

  return (
    <div className="portfolio-page">
      <div className="portfolio-overview">
        <div className="portfolio-header">
          <div className="portfolio-value">
            <h2>Portfolio Value</h2>
            <div className="value-container">
              <span className="total-value">₹{portfolioData.totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              <div className={`change-container ${portfolioData.todayChange >= 0 ? 'positive' : 'negative'}`}>
                <span className="change">
                  {portfolioData.todayChange >= 0 ? '+' : ''}
                  ₹{portfolioData.todayChange.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
                <span className="change-percent">
                  ({portfolioData.todayChange >= 0 ? '+' : ''}
                  {portfolioData.todayChangePercent.toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>
          <div className="portfolio-metrics">
            <div className="metric">
              <span className="metric-label">Total Investment</span>
              <span className="metric-value">₹{portfolioData.totalInvestment.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="metric">
              <span className="metric-label">Total Gain/Loss</span>
              <div className={`metric-value ${portfolioData.totalGain >= 0 ? 'positive' : 'negative'}`}>
                ₹{portfolioData.totalGain.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                <span className="metric-percent">
                  ({portfolioData.totalGain >= 0 ? '+' : ''}
                  {portfolioData.totalGainPercent.toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="portfolio-chart">
          <Chart
            options={portfolioChartOptions}
            series={portfolioChartData}
            type="area"
            height={250}
          />
        </div>
      </div>

      <div className="holdings-section">
        <div className="section-header">
          <h2>Holdings</h2>
        </div>
        <div className="holdings-table">
          <div className="table-header">
            <div className="col-symbol">Symbol</div>
            <div className="col-shares">Shares</div>
            <div className="col-avg-price">Avg. Price</div>
            <div className="col-current">Current</div>
            <div className="col-value">Value</div>
            <div className="col-gain">Gain/Loss</div>
            <div className="col-actions">Actions</div>
          </div>
          <div className="table-body">
            {holdings.map((holding, index) => (
              <div key={index} className="table-row">
                <div className="col-symbol">{holding.symbol}</div>
                <div className="col-shares">{holding.shares}</div>
                <div className="col-avg-price">₹{holding.avgPrice.toFixed(2)}</div>
                <div className="col-current">₹{holding.currentPrice.toFixed(2)}</div>
                <div className="col-value">₹{holding.value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                <div className={`col-gain ${holding.gain >= 0 ? 'positive' : 'negative'}`}>
                  ₹{Math.abs(holding.gain).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  <span className="gain-percent">
                    ({holding.gain >= 0 ? '+' : '-'}
                    {Math.abs(holding.gainPercent).toFixed(2)}%)
                  </span>
                </div>
                <div className="col-actions">
                  <button
                    className="action-btn buy"
                    onClick={() => {
                      setSelectedStock(holding);
                      setTradeType('buy');
                      setIsTradeModalOpen(true);
                    }}
                  >
                    Buy
                  </button>
                  <button
                    className="action-btn sell"
                    onClick={() => {
                      setSelectedStock(holding);
                      setTradeType('sell');
                      setIsTradeModalOpen(true);
                    }}
                  >
                    Sell
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="transactions-section">
        <h2>Recent Transactions</h2>
        <div className="transactions-table">
          <div className="table-header">
            <div className="col-date">Date</div>
            <div className="col-symbol">Symbol</div>
            <div className="col-type">Type</div>
            <div className="col-shares">Shares</div>
            <div className="col-price">Price</div>
            <div className="col-total">Total</div>
          </div>
          <div className="table-body">
            {transactions.map((transaction, index) => (
              <div key={index} className="table-row">
                <div className="col-date">{new Date(transaction.date).toLocaleDateString('en-IN')}</div>
                <div className="col-symbol">{transaction.symbol}</div>
                <div className={`col-type ${transaction.type.toLowerCase()}`}>{transaction.type}</div>
                <div className="col-shares">{transaction.shares}</div>
                <div className="col-price">₹{transaction.price.toFixed(2)}</div>
                <div className="col-total">₹{transaction.total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <TradeModal
        isOpen={isTradeModalOpen}
        onClose={() => {
          setIsTradeModalOpen(false);
          setSelectedStock(null);
          setTradeType(null);
        }}
        stock={selectedStock}
        type={tradeType}
        onTrade={handleTrade}
      />
    </div>
  );
};

export default Portfolio; 